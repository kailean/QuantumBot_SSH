
# pump_scanner.py — QuantumBot Firestorm: Pump.Fun Alpha Scanner

import requests

PUMP_FUN_API = "https://pump.fun/api/trending"

def fetch_trending_pumpfun(limit=10):
    """Fetch trending new tokens from Pump.fun."""
    try:
        res = requests.get(PUMP_FUN_API, timeout=5)
        data = res.json()

        trending = []
        for item in data[:limit]:
            trending.append({
                "symbol": item.get("tokenSymbol", "???"),
                "mintAddress": item.get("tokenAddress", ""),
                "volume_24h": float(item.get("volume", 0))
            })
        print(f"[PUMP.FUN] Fetched {len(trending)} trending tokens.")
        return trending
    except Exception as e:
        print(f"[PUMP.FUN ERROR] {e}")
        return []
 
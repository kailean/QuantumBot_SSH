
# trade_logger.py
import firebase_admin
from firebase_admin import credentials, firestore
from config import FIREBASE_CREDENTIALS

def init_firestore():
    if not firebase_admin._apps:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS)
        firebase_admin.initialize_app(cred)
    return firestore.client()

db = init_firestore()

def log_trade(trade_data: dict):
    """Log a completed trade into Firebase."""
    trade_id = trade_data.get("trade_id", None)
    if not trade_id:
        from uuid import uuid4
        trade_id = str(uuid4())

    db.collection('trade_logs').document(trade_id).set(trade_data)
    print(f"[TRADE LOGGED] {trade_id} into Firestore.")

import firebase_admin
from firebase_admin import credentials, firestore, initialize_app
import os, json
from datetime import datetime

FIREBASE_CREDENTIALS = "quantumbot-gpt-firebase-adminsdk-fbsvc.json"

def init_firestore():
    cred = credentials.Certificate(FIREBASE_CREDENTIALS)
    initialize_app(cred)
    return firestore.client()

db = init_firestore()

def log_gpt_decision(symbol, mint, prompt, decision):
    doc = {
        "symbol": symbol,
        "mint": mint,
        "prompt": prompt,
        "decision": decision,
        "timestamp": datetime.utcnow().isoformat()
    }
    db.collection("gpt_decisions").add(doc)

def log_trade(data):
    db.collection("executed_trades").add(data)

def fetch_gpt_logs(limit=10):
    """Fetch GPT decision logs sorted by time desc."""
    docs = db.collection('gpt_decisions').order_by("timestamp", direction=firestore.Query.DESCENDING).limit(limit).stream()
    return [
        {
            "decision": doc.to_dict().get("decision", "unknown"),
            "timestamp": doc.to_dict().get("timestamp")
        }
        for doc in docs
    ]

def fetch_trade_logs(limit=10):
    """Fetch latest sniper trade logs."""
    docs = db.collection('executed_trades').order_by("timestamp", direction=firestore.Query.DESCENDING).limit(limit).stream()
    return [
        {
            "token": doc.to_dict().get("token", "N/A"),
            "price": doc.to_dict().get("price", 0),
            "timestamp": doc.to_dict().get("timestamp")
        }
        for doc in docs
    ]
# QuantumBot-GPTIO: Godmode Edition

## 🚀 How to Run

### Local or Replit Terminal:
```bash
streamlit run app.py
```

### First-Time Setup
```bash
pip install -r requirements.txt
```

## 🧠 Features
- 🔥 Real-time SOL & meme coin prices from Jupiter API
- 🤖 LSTM + GPT prediction engine
- 🗳 DAO strategy voting
- 🧰 Firebase trade + GPT logging
- 🧠 Ollama GPT agent integration

## 📦 Folder Structure

```
QuantumBot-GPTIO/
├── app.py
├── main.py
├── live_market.py
├── dao_voting.py
├── src/
│   ├── __init__.py
│   └── strategy_engine.py
├── firebase_logger.py
├── lstm_model.py
├── gpt_engine.py
├── gpt_agent.py
├── requirements.txt
├── .env
├── README.md
```

## 🔐 Required Environment Variables (see `.env.example`)
Set these in Replit Secrets tab or in `.env` file:

- `OPENAI_API_KEY`
- `FIREBASE_PROJECT_ID`
- `DEFAULT_TOKEN=SOL`
- `BIRDEYE_API_KEY`


#!/bin/bash

echo ">>> [BOOT] QuantumBazooka V6.0 Startup"
echo ">>> [ENV] Loading .env variables..."

# Load .env cleanly
while IFS='=' read -r key value || [[ -n "$key" ]]; do
  if [[ "$key" =~ ^[A-Z0-9_]+$ ]]; then
    export "$key=$value"
    echo "[OK] $key loaded"
  fi
done < .env

echo ">>> [ENGINE] Launching app.py..."
streamlit run app.py --server.port $PORT


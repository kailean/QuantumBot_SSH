
from openai import OpenAIError

def test_openai_key():
    try:
        result = ask_gpt_agent("Hello!")
        print(result)
    except OpenAIError as e:
        print("OPENAI ERROR:", e)

if __name__ == "__main__":
    test_openai_key()

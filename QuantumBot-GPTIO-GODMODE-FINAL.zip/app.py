import streamlit as st
st.set_page_config(page_title="QuantumBot.IO - Galactic Dashboard", layout="wide")

# Import other necessary modules and packages after Streamlit config
from dotenv import load_dotenv
import os
if not load_dotenv():
    print("[WARN] .env file not found or empty")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
if not OPENAI_API_KEY:
    print("[ERROR] OPENAI_API_KEY missing from environment.")

import subprocess
import os
import pandas as pd
import altair as alt
from wallet_viewer import get_sol_balance
from firebase_logger import fetch_gpt_logs, fetch_trade_logs
from live_market import fetch_live_price

# SIDEBAR
st.sidebar.title("QuantumBazooka Controls")

if "sniper_active" not in st.session_state:
    st.session_state.sniper_active = False

toggle = st.sidebar.toggle("Activate AutoSniper", value=st.session_state.sniper_active)

if toggle and not st.session_state.sniper_active:
    st.session_state.sniper_active = True
    st.sidebar.success("AutoSniper launched.")
    subprocess.Popen(["python3", "main.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

elif not toggle and st.session_state.sniper_active:
    st.session_state.sniper_active = False
    st.sidebar.warning("Sniper still running in background. Restart shell to stop.")

# MAIN HEADER
st.markdown("# QuantumBazooka Dashboard V5.2.2")
st.caption("Dimensional Trading Engine | LSTM + GPT + DAO")

# --- WALLET BALANCE ---
st.subheader("Wallet Balance")
wallet_address = st.text_input("Wallet Address", placeholder="Enter your SOL wallet address")
if wallet_address:
    try:
        balance = get_sol_balance(wallet_address)
        st.metric(label="SOL Balance", value=f"{balance:.4f} SOL")
    except Exception as e:
        st.error(f"Error fetching balance: {e}")
else:
    st.info("Please enter your wallet address to view SOL balance.")

# --- AI Forecast Chart ---
st.subheader("AI Forecast Chart")
tokens = ["SOL", "BONK", "WIF", "DOG", "SAMO"]

for token in tokens:
    try:
        price = fetch_live_price(token)
        st.metric(label=f"{token} Price", value=f"${price:.4f}")
    except Exception as e:
        st.error(f"Error fetching price for {token}: {e}")

        if len(prices) > 0:
            chart_data = [{"index": i, "value": v, "series": "Historical"} for i, v in enumerate(prices)]
            if predicted:
                chart_data.append({"index": len(prices), "value": predicted, "series": "Predicted"})

            df = pd.DataFrame(chart_data)

            chart = alt.Chart(df).mark_line(point=True).encode(
                x=alt.X("index", title="Time Step"),
                y=alt.Y("value", title="Price (SOL)"),
                color=alt.Color("series", legend=alt.Legend(title="Source")),
                tooltip=["index", "value", "series"]
            ).properties(width=700, height=400)

            st.altair_chart(chart, use_container_width=True)
        else:
            st.warning("No price history available.")
    except Exception as e:
        st.error(f"Error fetching features: {e}")

# --- GPT DECISION LOG ---
st.subheader("GPT Decision Log")
try:
    gpt_logs = fetch_gpt_logs()
    if gpt_logs:
        st.dataframe(pd.DataFrame(gpt_logs).sort_values("timestamp", ascending=False))
    else:
        st.info("No GPT logs found.")
except Exception as e:
    st.error(f"Failed to load GPT logs: {e}")

# --- TRADE HISTORY ---
st.subheader("Sniper Trade History")
try:
    trade_logs = fetch_trade_logs()
    if trade_logs:
        st.dataframe(pd.DataFrame(trade_logs).sort_values("timestamp", ascending=False))
    else:
        st.info("No trade history found.")
except Exception as e:
    st.error(f"Failed to load trade logs: {e}")

# FOOTER
st.markdown("---")
st.caption("QuantumBot.IO © Kai Lienhard - Powered by OpenAI + Firebase + Solana")
st.set_page_config(page_title="QuantumBot.IO - Galactic Dashboard", layout="wide")
st.title("🚀 QuantumBot Live Price Tracker")

tokens = ["SOL", "BONK", "WIF", "DOG", "SAMO"]

cols = st.columns(len(tokens))
for i, token in enumerate(tokens):
    price = fetch_live_price(token)
    cols[i].metric(label=f"{token} Price", value=f"${price:.4f}")
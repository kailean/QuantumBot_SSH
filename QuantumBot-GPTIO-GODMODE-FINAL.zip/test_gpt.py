from gpt_engine import ask_gpt_agent

result = ask_gpt_agent("BUY or HODL?")
print("GPT Agent says:", result)
import requests
import time
import os

import os
from dotenv import load_dotenv

load_dotenv()

HELIUS_API_KEY = os.getenv("HELIUS_API_KEY")
NEW_API_KEY = os.getenv("NEW_API_KEY")

RPC_LIST = [
    f"https://rpc.helius.xyz/?api-key={HELIUS_API_KEY}",
    "https://api.mainnet-beta.solana.com",
    "https://rpc.publicnode.com/solana"
]
RPC_LIST = [
    f"https://rpc.helius.xyz/?api-key={HELIUS_API_KEY}",
    "https://api.mainnet-beta.solana.com",
    "https://rpc.publicnode.com/solana"
]


def get_sol_balance(wallet_address: str) -> float:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getBalance",
        "params": [wallet_address]
    }

    headers = {"Content-Type": "application/json"}

    for rpc in RPC_LIST:
        try:
            response = requests.post(rpc, json=payload, headers=headers, timeout=10)
            if response.status_code != 200:
                print(f"[RPC Error] {rpc} returned HTTP {response.status_code}")
                continue

            data = response.json()
            if "result" in data and "value" in data["result"]:
                lamports = data["result"]["value"]
                sol = lamports / 1_000_000_000
                return round(sol, 4)
            else:
                print(f"[Auto-Heal] No 'result.value' in response from {rpc}")
                print("Raw Response:", data)

        except Exception as e:
            print(f"[Wallet Fetch Error] Failed on {rpc}. Reason: {e}")

        time.sleep(1)  # Avoid rate limits

    print("[Wallet Fetch Error]: All RPCs failed. Returning 0.0 SOL.")
    return 0.0 
# dao_voting.py

import firebase_admin
from firebase_admin import credentials, firestore
from config import FIREBASE_CREDENTIALS
from datetime import datetime, timedelta
import requests

# Initialize Firestore only once
def init_firestore():
    if not firebase_admin._apps:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS)
        firebase_admin.initialize_app(cred)
    return firestore.client()

db = init_firestore()

def start_voting_session(session_id, duration_seconds=60):
    """Start a new DAO voting session."""
    try:
        now = datetime.utcnow()
        end_time = now + timedelta(seconds=duration_seconds)
        db.collection('voting_sessions').document(session_id).set({
            'start_time': now,
            'end_time': end_time,
            'votes': {}
        })
    except Exception as e:
        log_error(e, context="Starting voting session in dao_voting")

def record_vote(session_id, voter_id, choice):
    """Record a user's vote if session is active."""
    try:
        session_ref = db.collection('voting_sessions').document(session_id)
        session = session_ref.get()

        if session.exists:
            data = session.to_dict()
            end_time = data.get('end_time')

            if isinstance(end_time, datetime):
                end_time = end_time.replace(tzinfo=None)

            if datetime.utcnow() < end_time:
                votes = data.get('votes', {})
                votes[voter_id] = choice
                session_ref.update({'votes': votes})

                if voter_id == "gpt-voter":
                    db.collection('gpt_votes').add({
                        'timestamp': datetime.utcnow(),
                        'decision': choice
                    })
            else:
                print("[DAO] Voting session closed already.")
        else:
            print("[DAO] Voting session not found.")
    except Exception as e:
        log_error(e, context="Recording vote in dao_voting")


def ask_chatgpt_vote_strategy():
    """Let GPT cast emergency DAO vote."""
    try:
        prompt = "Based on the current market logs, should we vote aggressive or conservative?"
        response = requests.post("http://localhost:11434/api/generate", json={
            "model": "mistral",
            "prompt": prompt,
            "stream": False
        }, timeout=10)

        decision = response.json()["response"].lower()

        if "aggressive" in decision:
            return {"aggressive": 1, "conservative": 0}
        elif "conservative" in decision:
            return {"aggressive": 0, "conservative": 1}
        else:
            raise ValueError("[GPT-VOTE] Unexpected decision format: " + str(decision))

    except Exception as e:
        log_error(e, context="GPT agent call in dao_voting")
        return {"aggressive": 0, "conservative": 1}

def calculate_votes(session_id):
    """Tally votes after session ends and inject fallback GPT vote if needed."""
    try:
        session_ref = db.collection('voting_sessions').document(session_id)
        session = session_ref.get()

        if session.exists:
            data = session.to_dict()
            votes = data.get('votes', {})
            result = {'aggressive': 0, 'conservative': 0}
            for v in votes.values():
                result[v] = result.get(v, 0) + 1

            # Auto GPT fallback if no votes cast
            if result["aggressive"] == 0 and result["conservative"] == 0:
                print("[DAO] No votes found — triggering GPT fallback...")
                ai_vote = ask_chatgpt_vote_strategy()
                record_vote(session_id, "gpt-voter", "aggressive" if ai_vote["aggressive"] else "conservative")
                return ai_vote

            return result
        else:
            print("[DAO] Session not found during vote tally.")
            return {}
    except Exception as e:
        log_error(e, context="Vote calculation in dao_voting")

def get_current_votes(session_id):
    """Live-view of votes for frontend."""
    try:
        session_ref = db.collection('voting_sessions').document(session_id)
        session = session_ref.get()

        if session.exists:
            data = session.to_dict()
            return data.get('votes', {})
        else:
            print("[DAO] Cannot fetch votes — session missing.")
            return {}
    except Exception as e:
        log_error(e, context="Fetching current votes in dao_voting")
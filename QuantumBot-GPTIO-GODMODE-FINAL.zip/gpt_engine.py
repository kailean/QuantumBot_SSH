import requests
import os

# Load configs from env
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "mistral")
OLLAMA_URL = os.getenv("OLLAMA_ENDPOINT")  # Hard-coded from Replit Secret
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_FALLBACK_MODEL = os.getenv("OPENAI_MODEL", "gpt-4")

def get_ngrok_url():
    try:
        res = requests.get("http://127.0.0.1:4040/api/tunnels")
        tunnels = res.json().get("tunnels", [])
        for t in tunnels:
            if t["proto"] == "https":
                return t["public_url"]
    except Exception as e:
        print("[NGROK ERROR]", e)
        return None

def ask_gpt_agent(prompt: str):
    """Use Ollama via a hard-coded URL from Replit Secret."""
    try:
        endpoint = OLLAMA_URL or get_ngrok_url()
        if endpoint:
            res = requests.post(
                f"{endpoint}/api/generate",
                json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
                headers={"Content-Type": "application/json"}
            )
            return res.json().get("response", "").strip()
    except Exception as e:
        log_error(e, context="GPT agent call")

    # Fallback to OpenAI if local fails
    try:
        import openai
        openai.api_key = OPENAI_API_KEY
        res = openai.ChatCompletion.create(
            model=OPENAI_FALLBACK_MODEL,
            messages=[
                {"role": "system", "content": "Reply with only BUY, SELL, or HODL."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        return res['choices'][0]['message']['content'].strip()
    except Exception as e:
        print("[OpenAI Error]", e)
        return "HODL"  # Safe default
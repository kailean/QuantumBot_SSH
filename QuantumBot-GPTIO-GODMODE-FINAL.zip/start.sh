#!/bin/bash
echo ">>> Booting QuantumBazooka Godmode V5.3"
export PYTHONUNBUFFERED=1

# Optional: DNS Fix
# echo "nameserver 1.1.1.1" > /etc/resolv.conf

# Activate venv if exists
[ -d .venv ] && source .venv/bin/activate

# Auto-pull deps
# Check and source .env
echo ">>> Initiating QuantumBot Enhancement V2"
export PYTHONUNBUFFERED=1

echo "[SETUP] Performing environment config..."
python -c 'from dotenv import load_dotenv; load_dotenv()' || echo "[!] dotenv didn’t load"

echo "[PIP] Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Launch QuantumBot
python app.py
#!/bin/bash

echo ">>> Initiating QuantumBot Enhancement V2"
export PYTHONUNBUFFERED=1

echo "[SETUP] Performing environment config..."
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

echo "[PIP] Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[READY] Launching QuantumBot..."
python app.py

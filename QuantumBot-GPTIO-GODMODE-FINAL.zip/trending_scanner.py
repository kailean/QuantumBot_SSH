import requests
import time
import socket
import os
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

def requests_retry_session(retries=3, backoff_factor=0.3, status_forcelist=(500, 502, 504), session=None):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

def check_dns():
    try:
        socket.gethostbyname("price.jup.ag")
        return True
    except socket.gaierror:
        print("[DNS ERROR] price.jup.ag unreachable. Switching to fallback mode.")
        return False

def safe_json(response):
    try:
        return response.json()
    except Exception as e:
        print("[JSON ERROR]", e)
        return {}

def fetch_jup_price():
    try:
        response = requests.get("https://price.jup.ag/v4/price?ids=sol", timeout=3)
        data = safe_json(response).get("data", {})
        # Return as list of one dummy token (to not break flow)
        return [{"symbol": "SOL", "price": data.get("sol", {}).get("price", 0), "volume_24h": 0}]
    except Exception as e:
        print("[DNS ERROR] price.jup.ag unreachable:", e)
        return []

def fetch_fallback_trending():
    try:
        response = requests.get("https://api.birdeye.so/public/tokenlist?sort_by=volume_24h_usd", headers={
            "X-API-KEY": os.getenv("BIRDEYE_API_KEY", "")
        })
        tokens = safe_json(response).get("data", [])
        return [{"symbol": t.get("symbol", "?"), "price": t.get("price", 0), "volume_24h": t.get("volume_24h_usd", 0)} for t in tokens]
    except Exception as e:
        print("[FALLBACK ERROR]", e)
        return []

def fetch_trending_tokens(limit=5):
    trending = fetch_jup_price()
    if not trending:
        trending = fetch_fallback_trending()
    return trending[:limit] if trending else []

def auto_fetch_trending_tokens(interval_seconds=60):
    """Keep fetching trending tokens every X seconds."""
    while True:
        trending = fetch_trending_tokens(limit=5)
        if not trending:
            print("[TRENDING] No tokens found. Cooling...")
        else:
            print("Trending Tokens:")
            for token in trending:
                print(f"- {token['symbol']} at {token['price']} SOL (Vol {token['volume_24h']:,})")
        time.sleep(interval_seconds)

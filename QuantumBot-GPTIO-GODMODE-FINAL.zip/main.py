import streamlit as st
from src.firebase_utils import load_trade_logs, load_wallets
from src.strategy_engine import get_gpt_decision
from src.visuals import plot_price_chart

# UI Configuration
st.set_page_config(layout="wide")
st.title("🧠 QuantumBot-GPTIO Godmode Dashboard")

# Columns for different views
col1, col2 = st.columns(2)

with col1:
    st.header("📊 Trade Logs")
    trade_logs = load_trade_logs()
    st.dataframe(trade_logs)

with col2:
    st.header("💼 Wallet Viewer")
    wallet_data = load_wallets()
    st.dataframe(wallet_data)

st.header("📈 Live Chart + Forecast")
plot_price_chart()

st.header("🧠 GPT Strategy Decision")
st.code(get_gpt_decision())
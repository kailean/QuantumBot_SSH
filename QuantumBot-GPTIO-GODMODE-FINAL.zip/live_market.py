import os
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import numpy as np
from datetime import datetime
from lstm_model import train_token_lstm_model, predict_token_next_price
from price_oracle import get_token_price
from dotenv import load_dotenv
import os

if not load_dotenv():
    print("[WARN] .env file not found or empty")

DEFAULT_TOKEN = os.getenv("DEFAULT_TOKEN", "SOL")
if not DEFAULT_TOKEN:
    print("[ERROR] DEFAULT_TOKEN missing from environment.")
DEFAULT_TOKEN = os.getenv("DEFAULT_TOKEN", "SOL")
BIRDEYE_API_KEY = os.getenv("BIRDEYE_API_KEY")
BIRDEYE_URL = "https://public-api.birdeye.so/public"

def fetch_live_price(token_symbol=DEFAULT_TOKEN):
    session = requests_retry_session()
    url = f"https://price.jup.ag/v4/price?ids={token_symbol}"
    try:
        response = session.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        price = data["data"].get(token_symbol, {}).get("price", 0.0)
        print(f"[PRICE] {token_symbol.upper()} = ${price:.4f}")
        return price
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Price API unreachable: {e}")
        return 0.0
    except Exception as e:
        print(f"[ERROR] Failed to fetch price for {token_symbol}: {e}")
        return 0.0

def fetch_token_metadata(mint_address):
    """Fetch token info from Birdeye."""
    try:
        url = f"{BIRDEYE_URL}/token/{mint_address}"
        headers = {"X-API-KEY": BIRDEYE_API_KEY}
        res = requests.get(url, headers=headers, timeout=6)
        if res.status_code != 200:
            raise Exception(f"HTTP {res.status_code}")
        data = res.json().get("data", {})
        if not isinstance(data, dict):
            raise ValueError("Invalid metadata format")

        return {
            "symbol": data.get("symbol", "???"),
            "decimals": data.get("decimals", 9),
            "logo": data.get("logoURI", ""),
            "volume_24h": data.get("volume24h", 0.0),
            "price": data.get("price", 0.0),
            "mintAddress": mint_address
        }
    except Exception as e:
        print(f"[Metadata ERROR] {e}")
        return {
            "symbol": "???",
            "price": 0.0,
            "decimals": 9,
            "mintAddress": mint_address
        }

def fetch_token_price_fallback():
    """Provide a hardcoded fallback price."""
    return {"symbol": "SOL", "price": 159.12}

def get_price_features(mint_address):
    """Get live + predicted price + full snapshot for GPT chart."""
    try:
        live_price = fetch_live_price(mint_address)
        if not live_price or live_price == 0.0:
            print("[LSTM FALLBACK] No price. Returning empty snapshot.")
            return {
                "live_price": 0.0,
                "lstm_prediction": 0.0,
                "timestamp": datetime.utcnow().isoformat(),
                "history": [],
                "predictions": []
            }

        def tune_lstm_hyperparams(data):
            print("Tuning LSTM hyperparameters with advanced settings...")
            pass  # Placeholder for real tuning logic

# Mocked price history
        history = [
            round(live_price * 0.95, 6),
            round(live_price * 0.97, 6),
            round(live_price * 0.99, 6),
            round(live_price * 1.01, 6),
            round(live_price * 1.03, 6)
        ]

        model, scaler = train_token_lstm_model(history, time_step=3)
        prediction = predict_token_next_price(model, scaler, history, time_step=3)

        return {
            "live_price": round(live_price, 6),
            "lstm_prediction": round(prediction, 6),
            "timestamp": datetime.utcnow().isoformat(),
            "history": history,
            "predictions": [round(prediction, 6)] * 5
        }
    except Exception as e:
        log_error(e, context="Price feature retrieval in live_market")
        return {
            "live_price": 0.0,
            "lstm_prediction": 0.0,
            "timestamp": datetime.utcnow().isoformat(),
            "history": [],
            "predictions": []
        }

# Test
if __name__ == "__main__":
    test_mint = "So11111111111111111111111111111111111111112"
    print(get_price_features(test_mint))
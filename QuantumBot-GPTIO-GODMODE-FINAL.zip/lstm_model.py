import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

import tensorflow as tf
tf.get_logger().setLevel('ERROR')



import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Input
from sklearn.preprocessing import MinMaxScaler
import pandas as pd

def create_dataset(dataset, time_step=1):
    dataX, dataY = [], []
    for i in range(len(dataset)-time_step-1):
        a = dataset[i:(i+time_step), 0]   
        dataX.append(a)
        dataY.append(dataset[i + time_step, 0])
    return np.array(dataX), np.array(dataY)


def train_lstm_model(price_series):
    """Original function to train LSTM model from a list of price floats."""
    scaler = MinMaxScaler(feature_range=(0, 1))
    df = pd.DataFrame(price_series, columns=['price'])
    scaled = scaler.fit_transform(df)

    X, y = create_dataset(scaled)
    X = X.reshape(X.shape[0], X.shape[1], 1)

    model = Sequential([
        Input(shape=(X.shape[1], 1)),
        LSTM(50),
        Dense(1)
    ])
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(X, y, epochs=10, batch_size=1, verbose=1)

    return model, scaler


def predict_next_price(model, scaler, recent_prices):
    """Original function to predict the next price from last N prices."""
    recent_scaled = scaler.transform(np.array(recent_prices).reshape(-1, 1))
    input_seq = recent_scaled[-10:].reshape(1, 10, 1)
    try:
        prediction_scaled = model.predict(input_seq)
        prediction = scaler.inverse_transform(prediction_scaled)
        return float(prediction[0][0])
    except Exception as e:
        log_error(e, context="LSTM prediction in lstm_model")
        return None



def train_token_lstm_model(prices, time_step=3):
    try:
        if len(prices) < time_step + 1:
            print("[LSTM] Not enough price data to train.")
            return None, None

        prices = np.array(prices).reshape(-1, 1)
        scaler = MinMaxScaler()
        prices_scaled = scaler.fit_transform(prices)

        X, y = [], []
        for i in range(len(prices_scaled) - time_step):
            X.append(prices_scaled[i:i + time_step])
            y.append(prices_scaled[i + time_step])

        X, y = np.array(X), np.array(y)

        model = Sequential()
        model.add(Input(shape=(time_step, 1)))
        model.add(LSTM(64))
        model.add(Dense(1))
        model.compile(optimizer="adam", loss="mse")
        model.fit(X, y, epochs=5, batch_size=1, verbose=0)

        return model, scaler
    except Exception as e:
        log_error(e, context="LSTM training in lstm_model")
        return None, None


def predict_token_next_price(model, scaler, price_series, time_step=5):
    """Predict next price point for token."""
    try:
        inputs = np.array(price_series[-time_step:]).reshape(-1, 1)
        inputs_scaled = scaler.transform(inputs)
        X_test = np.array([inputs_scaled])
        prediction = model.predict(X_test, verbose=0)
        prediction = scaler.inverse_transform(prediction)
        return prediction[0][0]
    except Exception as e:
        log_error(e, context="LSTM prediction in lstm_model")
        return None

def log_error(e, context):
    print(f"Error in {context}: {e}")
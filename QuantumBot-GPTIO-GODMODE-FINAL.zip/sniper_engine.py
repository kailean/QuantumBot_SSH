# sniper_engine.py — Firestorm Fusion Sniper

from live_market import get_price_features
from gpt_engine import ask_gpt_agent
from firebase_logger import log_trade, log_gpt_decision
from solana_sniper import snipe_token
from config import DRY_RUN
from datetime import datetime
import time

LSTM_THRESHOLD = 1.04
COOLDOWN_SECONDS = 10

def sniper_logic(token, mode="conservative"):
    try:
        print(f"[TARGET] {token['symbol']}")
        features = get_price_features(token["mintAddress"])

        live = features['live_price']
        pred = features['lstm_prediction']

        print(f"[ORACLE] Live: {live} | LSTM: {pred}")

        prompt = f"""
        SOLANA TOKEN SNAPSHOT:

        Symbol: {token['symbol']}
        Live Price: {live:.6f}
        Predicted Price: {pred:.6f}
        24H Volume: {token['volume_24h']:,}

        Should I execute sniper BUY?
        Respond ONLY with: BUY / HOLD / IGNORE
        """

        decision = ask_gpt_agent(prompt).strip().upper()
        if not (decision.startswith("BUY") or decision.startswith("HODL") or decision.startswith("IGNORE")):
            decision = "ERROR"

        log_gpt_decision({
            "symbol": token["symbol"],
            "decision": decision,
            "price": live,
            "predicted": pred,
            "volume": token["volume_24h"],
            "timestamp": features["timestamp"]
        })

        if decision == "BUY" and pred > live * LSTM_THRESHOLD:
            amount = 0.005
            if DRY_RUN:
                print(f"[DRY RUN] Would snipe {token['symbol']} at {live} SOL")
            else:
                tx = snipe_token(token["mintAddress"], amount_sol=amount)
                log_trade({
                    "symbol": token["symbol"],
                    "action": "BUY",
                    "amount": amount,
                    "price": live,
                    "predicted": pred,
                    "tx": tx,
                    "timestamp": datetime.utcnow().isoformat()
                })
                print(f"[SNIPED] {token['symbol']} @ {live} SOL")
            time.sleep(COOLDOWN_SECONDS)
        else:
            print(f"[IGNORE] {token['symbol']} not bullish enough.")
    except Exception as e:
        log_error(e, context="Sniper logic execution")
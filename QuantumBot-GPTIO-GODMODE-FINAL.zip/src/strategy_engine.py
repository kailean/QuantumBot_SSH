
def get_gpt_decision():
    # Placeholder logic
    return "HODL"


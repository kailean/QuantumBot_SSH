# === godmode_ollama.py ===
# Step 2: Dimensional Market Sentiment via Local Ollama (DeepSeek-Coder)
# Step 4: Time-Looped Prediction Cache (LSTM + GPT memory)

import requests
import os
import json
from datetime import datetime
from pathlib import Path

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "deepseek-coder")
CACHE_FILE = Path(".prediction_cache.json")

# Load cache if exists
if CACHE_FILE.exists():
    with open(CACHE_FILE, "r") as f:
        prediction_cache = json.load(f)
else:
    prediction_cache = {}

def ask_ollama(prompt):
    try:
        res = requests.post(f"{OLLAMA_URL}/api/generate", json={
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        }, timeout=20)
        res.raise_for_status()
        return res.json()["response"].strip()
    except Exception as e:
        print(f"[Ollama ERROR] {e}")
        return "HODL"

def get_prediction(symbol, prompt):
    today = datetime.utcnow().strftime("%Y-%m-%d")
    key = f"{symbol}_{today}"

    # Return cached if exists
    if key in prediction_cache:
        return prediction_cache[key]

    response = ask_ollama(prompt)
    prediction_cache[key] = response

    with open(CACHE_FILE, "w") as f:
        json.dump(prediction_cache, f, indent=2)

    return response

# === USAGE EXAMPLE ===
if __name__ == "__main__":
    test_prompt = "SOLANA TOKEN\nPrice: 0.0021\nPredicted: 0.0026\nVol: 40000\nBUY/SELL/HODL?"
    print(get_prediction("SOLTEST", test_prompt))
 
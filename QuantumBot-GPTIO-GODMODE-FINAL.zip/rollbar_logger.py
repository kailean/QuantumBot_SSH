
# rollbar_logger.py
import os
import rollbar

def init_rollbar():
    rollbar.init(
        access_token=os.getenv("ROLLBAR_TOKEN"),
        environment="production",
        code_version="v6.0",
        handler="thread"
    )
    rollbar.report_message("Rollbar active - QuantumBot V6.0", level="info")

def log_error(err, context=None):
    rollbar.report_exc_info(extra_data={"context": context})



# solana_sniper.py
import requests
from config import JUPITER_BASE_URL, PHANTOM_PUBLIC_KEY, DRY_RUN

def snipe_token(token_mint: str, amount_sol: float = 0.01):
    """Executes a buy trade for a Solana token using Jupiter aggregator."""
    url = f"{JUPITER_BASE_URL}/v6/swap"
    params = {
        "inputMint": "So11111111111111111111111111111111111111112",  # SOL
        "outputMint": token_mint,
        "amount": int(amount_sol * 10**9),  # Convert SOL to lamports
        "slippageBps": 50,
        "userPublicKey": PHANTOM_PUBLIC_KEY,
        "onlyDirectRoutes": True
    }

    if DRY_RUN:
        print(f"[DRY RUN] Would snipe {token_mint} for {amount_sol} SOL")
        return

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        result = response.json()
        print("[SNIPE] Route planned:", result.get("routePlan"))
        return result
    except Exception as e:
        print("Sniper Error:", e)
        return None


# price_oracle.py — QuantumBot Firestorm Price Resolver

import requests
import os

# Endpoint configs
JUP_URL = "https://price.jup.ag/v4/price"
BIRDEYE_URL = "https://public-api.birdeye.so/public/price"
COINGECKO_URL = "https://api.coingecko.com/api/v3/simple/price"

# Optional API key (env-var)
BIRDEYE_API_KEY = os.getenv("BIRDEYE_API_KEY")

def get_token_price(mint_address: str) -> float:
    """Master function to fetch price with failover cascade: JUP -> Birdeye -> CoinGecko -> 0.0"""
    return (
        fetch_price_jupiter(mint_address) or
        fetch_price_birdeye(mint_address) or
        fetch_price_coingecko(mint_address) or
        0.0
    )

def fetch_price_jupiter(token_mint: str):
    try:
        res = requests.get(f"{JUP_URL}?ids={token_mint}", timeout=4)
        res.raise_for_status()
        data = res.json().get("data", {})
        price = data.get(token_mint, {}).get("price")
        if isinstance(price, (float, int)):
            return float(price)
    except Exception as e:
        print(f"[JUP ERROR] {e}")
    return None

def fetch_price_birdeye(token_mint: str):
    try:
        headers = {
            "X-API-KEY": BIRDEYE_API_KEY,
            "x-chain": "solana",  # required!
            "accept": "application/json"
        }
        res = requests.get(f"https://public-api.birdeye.so/defi/price?address={token_mint}", headers=headers, timeout=5)
        res.raise_for_status()
        return float(res.json().get("data", {}).get("value", 0.0))
    except Exception as e:
        print(f"[BIRDEYE ERROR] {e}")
    return None

def fetch_price_coingecko(token_mint: str):
    try:
        token_map = {
            "so11111111111111111111111111111111111111112": "solana",
            # Add more known mappings here if needed
        }
        token_id = token_map.get(token_mint.lower())
        if not token_id:
            return None
        res = requests.get(f"{COINGECKO_URL}?ids={token_id}&vs_currencies=usd", timeout=4)
        res.raise_for_status()
        return float(res.json()[token_id]["usd"])
    except Exception as e:
        print(f"[COINGECKO ERROR] {e}")
    return None
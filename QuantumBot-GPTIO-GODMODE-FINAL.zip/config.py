import os

# === FIREBASE ===
FIREBASE_CREDENTIALS = "quantumbot-gpt-firebase-adminsdk-fbsvc-8c08bce46c.json"

# === HELIUS ===
HELIUS_API_KEY = "426c14e8-e08c-4495-8e74-4f42020e8ca5"

# === LOCAL AI (Ollama/DeepSeek) ===
OLLAMA_ENDPOINT = "http://localhost:11434"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# === WALLET ===
PHANTOM_PUBLIC_KEY = "zyhURAz2xkC2aIdt8Vv1xnT48JdmeJXtD925JezRrcC"

# === JUPITER AGGREGATOR ===
JUPITER_BASE_URL = "https://quote-api.jup.ag"

# === OPENAI ===
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# === MODE ===
DRY_RUN = True  # Set to True while testing 

import requests
import os

# Environment-config variable for ngrok
GPT_SERVER = os.getenv("GPT_SERVER", "https://your-ngrok-url.ngrok-free.app")

def ask_gpt_agent(prompt: str):
    try:
        res = requests.post(
            f"{GPT_SERVER}/api/generate",
            json={"model": "mistral", "prompt": prompt, "stream": False},
            timeout=10
        )
        return res.json().get("response", "[ERROR]")
    except Exception as e:
        print(f"[GPT ERROR] {e}")
        return "[ERROR]"

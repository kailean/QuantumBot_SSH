#!/bin/bash

ENV_FILE=".env"

# Check .env existence
if [ ! -f "$ENV_FILE" ]; then
  echo "[ERROR] .env file not found!"
  exit 1
fi

# Filter and export valid lines only
echo "[INFO] Loading environment variables..."
while IFS='=' read -r key value || [ -n "$key" ]; do
  if [[ "$key" =~ ^[A-Z0-9_]+$ ]]; then
    export "$key=$value"
    echo "[OK] Loaded $key"
  else
    echo "[SKIP] Ignored invalid line: $key=$value"
  fi
done < "$ENV_FILE"

echo "[INFO] All valid variables loaded into shell."
